#!/usr/bin/env python3
"""Independent local-only million-case Privacy Guard runner; no provider/network calls."""
import argparse, hashlib, importlib, json, random, re, subprocess, sys, time, types
from collections import Counter
from pathlib import Path

TARGET = "06580f9a0258c8c0d6c3a79a82e3ff7974f0e41c"
BLOBS = {
 "pii_mask_abelion/__init__.py":"18813ab4e235d2afb3d577ec01b47a49ffc98b29",
 "pii_mask_abelion/_credentials.py":"342632a3ddba65669cbeabdc45bd75fcaf1135db",
 "pii_mask_abelion/_patterns.py":"ba8e5c86cc48f0a693a3b444fba2ef7368b2266a",
 "pii_mask_abelion/guard.py":"5dfd3b602f7a4627156f38785650036aea1116c9",
 "pii_mask_abelion/pii_middleware.py":"cc3be4fbd4d96d7edfd106dd7ef2b2a9afec3e15",
 "pii_mask_abelion/output_redact.py":"e4817d66f27f50c47dc8797859592a638f8665f5",
 "pii_mask_abelion/tests/test_classifier_case_invariance.py":"07b46bf216c7f76afca7051df05d3d676e5018e1",
}
WEIGHTS = {"field_classification":200000,"benign_false_positive":200000,
 "request_nested_payload":250000,"placeholder_session_boundary":200000,"output_redaction":150000}
SENSITIVE = [(n,v) for n,v in [
 ("password","SECRET"),("paSsWOrD","SECRET"),("servicePassword","SECRET"),
 ("service-password","SECRET"),("service_password","SECRET"),("service.password","SECRET"),
 ("clientSecret","SECRET"),("githubToken","SECRET"),("accessKey","SECRET"),
 ("secretKeyValue","SECRET"),("tokenSecret","SECRET"),("apiKeyPrimary","SECRET"),
 ("apiGithubKey","SECRET"),("api_key","SECRET"),("client_id","IDENTIFIER"),
 ("clientId","IDENTIFIER"),("appId","IDENTIFIER"),("publicKey","IDENTIFIER"),
 ("accountSid","IDENTIFIER"),("account_sid","IDENTIFIER"),("lmsEmail","IDENTIFIER"),
 ("emailGithub","IDENTIFIER")]]
BENIGN = [(n,None) for n in ["compass","CoMPASs","surpass","trespass","overpass","underpass",
 "tokenizer","tokenize","secretary","mypass","api_key_name","API_key_nAme",
 "passwordPolicy","tokenCount","secretFile","filename","model","maxTokens",
 "countGithubToken","filePassword","perPassword","fileNameToken","ordinaryMetadata"]]
CANARY = "SYNTHETIC_AUDIT_CANARY_"


def git(root,*args):
 p=subprocess.run(["git","-C",str(root),*args],text=True,capture_output=True)
 if p.returncode: raise RuntimeError(f"git {args[0]} exit {p.returncode}: {p.stderr.strip()[:240]}")
 return p.stdout.strip()

def preflight(root):
 head=git(root,"rev-parse","HEAD")
 if head!=TARGET: raise RuntimeError(f"wrong HEAD: expected {TARGET}, got {head}")
 seen={}
 for path,expected in BLOBS.items():
  actual=git(root,"hash-object",path); seen[path]={"git_blob_sha1":actual,"expected":expected,"match":actual==expected}
  if actual!=expected: raise RuntimeError(f"pinned source blob mismatch: {path}")
 return {"git_head":head,"source_blobs":seen,"source_hashes_match":True}

def fake_native_redactor():
 """Neutral test double, not the real Hermes agent.redact implementation."""
 a=types.ModuleType("agent"); a.__path__=[]
 r=types.ModuleType("agent.redact"); r._PREFIX_RE=re.compile(r"(?!)")
 r.redact_sensitive_text=lambda text:text
 a.redact=r; sys.modules["agent"]=a; sys.modules["agent.redact"]=r

def digest(obj):
 return hashlib.sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(",",":"),default=str).encode()).digest()
def case_variant(s,rng):
 return "".join(rng.choice((c.lower(),c.upper())) if c.isalpha() else c for c in s)
def allocations(n):
 total=sum(WEIGHTS.values()); out={k:n*v//total for k,v in WEIGHTS.items()}
 for i in range(n-sum(out.values())): out[list(WEIGHTS)[i%len(WEIGHTS)]]+=1
 return out

def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--source-root",required=True)
 ap.add_argument("--count",type=int,default=1000000); ap.add_argument("--seed",type=int,default=20261028)
 ap.add_argument("--output",required=True); args=ap.parse_args()
 if args.count<1: ap.error("--count must be positive")
 start=time.perf_counter(); counts=allocations(args.count); dest=Path(args.output).resolve(); dest.parent.mkdir(parents=True,exist_ok=True)
 result={"status":"NOT RUN","target_sha":TARGET,"seed":args.seed,"planned":args.count,"executed":0,
  "unique_inputs":0,"pass":0,"fail":0,"skip":0,"not_run":args.count,"assertions":0,
  "duration_seconds":None,"native_hermes":"NOT USED; neutral agent.redact test double only",
  "transport":"local direct calls; no network/provider/tool dispatch","domains":{},"failure_samples":[]}
 for name,n in counts.items(): result["domains"][name]={"planned":n,"executed":0,"unique_inputs":0,"pass":0,"fail":0,"skip":0,"not_run":n,"assertions":0}
 try:
  root=Path(args.source_root).resolve(); result["preflight"]=preflight(root)
  fake_native_redactor(); sys.path.insert(0,str(root))
  cred=importlib.import_module("pii_mask_abelion._credentials")
  Guard=importlib.import_module("pii_mask_abelion.guard").Guard
  MARKER=importlib.import_module("pii_mask_abelion.guard").MARKER
 except Exception as e:
  result.update(status="BLOCKED",blocker=f"{type(e).__name__}: {str(e)[:400]}",duration_seconds=round(time.perf_counter()-start,6))
  dest.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
  print(json.dumps({k:result[k] for k in ("status","planned","executed","not_run","blocker")},indent=2)); return 2

 rng=random.Random(args.seed); seen={k:set() for k in counts}; stats={k:Counter() for k in counts}; failures=[]; idx=0
 def record(domain,input_obj,checks,extra_inputs=()):
  nonlocal idx
  st=stats[domain]; seen[domain].add(digest(input_obj)); seen[domain].update(digest(x) for x in extra_inputs)
  st["executed"]+=1; st["assertions"]+=len(checks)
  ok=all(c[1] for c in checks); st["pass" if ok else "fail"]+=1
  if not ok and len(failures)<100:
   for label,condition,expected,actual in checks:
    if not condition: failures.append({"index":idx,"domain":domain,"assertion":label,"expected":expected,"actual":actual})
    if len(failures)>=100: break
  idx+=1

 for i in range(counts["field_classification"]):
  base,exp=SENSITIVE[i%len(SENSITIVE)]; name=case_variant(base,rng) if i%3 else base; actual=cred.classify_field(name)
  record("field_classification",name,[("expected-class",actual==exp,exp,actual),("valid-return-domain",actual in (None,"SECRET","IDENTIFIER"),"one documented class",actual)])
 for i in range(counts["benign_false_positive"]):
  base,exp=BENIGN[i%len(BENIGN)]; name=case_variant(base,rng) if i%2 else base; actual=cred.classify_field(name)
  record("benign_false_positive",name,[("documented-benign-exclusion",actual is None,None,actual),("return-domain",actual in (None,"SECRET","IDENTIFIER"),"valid class",actual)])

 oversize_n=max(1,counts["request_nested_payload"]//25000)
 for i in range(counts["request_nested_payload"]):
  secret=f"{CANARY}REQ_{i:08d}_Q7v2"; sid=f"req-{i}"
  raw={"model":"local-test-model","messages":[{"role":"user","content":{"records":[
   {"profile":{"password":secret,"email":f"audit{i}@example.invalid"}},
   {"meta":{"model":"ordinary-metadata","tokenCount":4096}}]}}]}
  oversized=i<oversize_n and counts["request_nested_payload"]>10
  if oversized: raw["messages"][0]["content"]["padding"]="z"*131100+f"-{i}"
  original=json.loads(json.dumps(raw)); g=Guard(); resp=g.required_policy("request",request=raw,session_id=sid)
  wire=json.dumps(resp.get("request",{}),sort_keys=True); should_allow=not oversized
  checks=[("allow-or-deny",resp.get("allow") is should_allow,should_allow,resp.get("allow")),
   ("canary-absent",secret not in wire,True,secret in wire),("input-immutable",raw==original,True,raw==original)]
  extra=[]
  if i%2500==0:
   malformed={"model":"local-test-model","messages":"not-a-list"}
   bad=g.required_policy("request",request=malformed,session_id=sid+"-bad")
   checks.append(("malformed-request-denied",bad.get("allow") is False,False,bad.get("allow"))); extra.append(malformed)
  record("request_nested_payload",raw,checks,extra); g.close(sid)

 for i in range(counts["placeholder_session_boundary"]):
  g=Guard(max_sessions=4); sid,other=f"ph-{i}",f"other-{i}"; secret=f"{CANARY}PH_{i:08d}_N4m8"
  tok=g.remember(g.session(sid),secret,"SECRET"); mode=i%4
  if mode==0:
   req={"model":"local-test-model","messages":[{"role":"user","content":tok}]}; got=g.required_policy("request",request=req,session_id=sid)
   inp={"op":"same-session-request","request":req,"session":sid}; checks=[("allow",got.get("allow") is True,True,got.get("allow")),("original-absent",secret not in json.dumps(got.get("request",{})),True,secret in json.dumps(got.get("request",{})))]
  elif mode==1:
   out=g.output(tok,session_id=other,platform="api"); inp={"op":"cross-session-output","token":tok,"session":other}
   checks=[("foreign-token-withheld",MARKER in out,True,MARKER in out),("secret-absent",secret not in out,True,secret in out)]
  elif mode==2:
   forged=tok[:-2]+("00" if tok[-2:]!="00" else "11"); req={"model":"local-test-model","messages":[{"role":"user","content":forged}]}
   got=g.required_policy("request",request=req,session_id=sid); inp={"op":"forged-token-request","request":req,"session":sid}
   checks=[("forged-denied",got.get("allow") is False,False,got.get("allow"))]
  else:
   malformed=f"<HG:{'a'*24}:not-hex-{i}>"; req={"model":"local-test-model","messages":[{"role":"user","content":malformed}]}
   got=g.required_policy("request",request=req,session_id=sid); inp={"op":"malformed-token-request","request":req,"session":sid}
   checks=[("malformed-denied",got.get("allow") is False,False,got.get("allow"))]
  record("placeholder_session_boundary",inp,checks); g.close(sid); g.close(other)

 templates=[lambda i:(f"password={CANARY}OUT_{i:08d}_x9",f"{CANARY}OUT_{i:08d}_x9"),
  lambda i:(f"tokenSecret: {CANARY}TOK_{i:08d}_m3",f"{CANARY}TOK_{i:08d}_m3"),
  lambda i:(f"{CANARY}PAR_{i:08d}_j4 (password)",f"{CANARY}PAR_{i:08d}_j4"),
  lambda i:(f"Contact audit{i}@example.invalid",f"audit{i}@example.invalid"),
  lambda i:(f"Normal reply number {i}; no credentials here.",None)]
 for i in range(counts["output_redaction"]):
  text,canary=templates[i%len(templates)](i); g=Guard(); out=g.output(text,session_id=f"out-{i}",platform="api")
  if canary is None: checks=[("benign-unchanged",out==text,True,out==text)]
  else: checks=[("canary-absent",canary not in out,True,canary in out)]
  record("output_redaction",text,checks); g.close(f"out-{i}")

 for name,n in counts.items():
  s=stats[name]; result["domains"][name]={"planned":n,"executed":s["executed"],"unique_inputs":len(seen[name]),
   "pass":s["pass"],"fail":s["fail"],"skip":0,"not_run":n-s["executed"],"assertions":s["assertions"]}
 result.update(executed=sum(s["executed"] for s in stats.values()),pass_count=sum(s["pass"] for s in stats.values()),
  fail_count=sum(s["fail"] for s in stats.values()),skip=0,assertions=sum(s["assertions"] for s in stats.values()),
  failure_samples=failures,duration_seconds=round(time.perf_counter()-start,6),
  unique_input_count_method="per-domain SHA-256 of canonical inputs; raw case rows not persisted")
 result["pass"]=result.pop("pass_count"); result["fail"]=result.pop("fail_count"); result["not_run"]=args.count-result["executed"]
 result["status"]="PASS" if result["fail"]==0 and result["not_run"]==0 else "FAIL"
 dest.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
 print(json.dumps({k:result[k] for k in ("status","target_sha","seed","planned","executed","unique_inputs","pass","fail","skip","not_run","assertions","duration_seconds","domains")},indent=2))
 return 0 if result["status"]=="PASS" else 1

if __name__=="__main__": raise SystemExit(main())
